package Gates;

import CircuitElement.CircuitElement;

/**
 * Auto Generated Java Class.
 */
public class AndGate extends Gates {
   
   public AndGate(CircuitElement prev1, CircuitElement prev2, CircuitElement next, String direction, int xPos, int yPos) {
      super( prev1, prev2, next, direction, xPos, yPos);
   }
   
   public String logicOperation()
   {
      if ( input1.equals("0") || input2.equals("0"))
      {
         return "0";
      }
      else
      {
         return "1";
      }
   }

   public String run()
   {
      if ( getPrev1() == null )
      {
         input1 = "0";
      }
      else
      {
         input1 = getPrev1().run();
      }

      if ( getPrev2() == null )
      {
         input2 = "0";
      }
      else
      {
         input2 = getPrev2().run();
      }

      setTempValue( logicOperation());
      return getTempValue();

   }

}
