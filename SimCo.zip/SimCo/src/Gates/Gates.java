package Gates;

import CircuitElement.CircuitElement;

/**
 * Auto Generated Java Class.
 */


public abstract class Gates extends CircuitElement
{
    //properties
    String input1;
    String input2;

    public Gates(CircuitElement prev1, CircuitElement prev2, CircuitElement next, String direction, int xPos, int yPos)
    {
        super( prev1, prev2, next, direction, xPos, yPos);
    }

    public Gates( CircuitElement prev1, CircuitElement next, String direction, int xPos, int yPos)
    {
        super( prev1, next, direction, xPos, yPos);
    }

    public String getInput1(){
        return input1;
    }

    public String getInput2(){
        return input2;
    }

    public abstract String logicOperation();
}