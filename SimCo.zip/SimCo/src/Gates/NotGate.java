package Gates;

import CircuitElement.CircuitElement;

/**
 * Auto Generated Java Class.
 */
public class NotGate extends Gates {
   
   public NotGate(CircuitElement prev1, CircuitElement next, String direction, int xPos, int yPos) {
      super( prev1, next, direction, xPos, yPos);
   }

   public String logicOperation()
   {
      if ( input1.equals( "0"))
      {
         return "1";
      }
      else
      {
         return "0";
      }
   }

   public String run() {
      if (getPrev1() == null) {
         input1 = "0";
      } else {
         input1 = getPrev1().run();
      }

      setTempValue( logicOperation());
      return getTempValue();

   }
}
