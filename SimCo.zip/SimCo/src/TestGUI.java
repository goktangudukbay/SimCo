import javax.swing.*;

public class TestGUI extends JFrame
{
    JPanel components;

    public TestGUI()
    {
        components = new JPanel();

        add( components);

        pack();
        setVisible( true);
    }

    public static void main( String[] args)
    {
        new TestGUI();
    }



}
