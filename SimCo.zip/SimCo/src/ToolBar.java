import javax.swing.*;

public class ToolBar extends JPanel
{

}
