import Circuit.WorkSpace;
import CircuitElement.*;
import Gates.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;


public class WorkspacePanel extends JPanel {
    WorkSpace ws;
    ArrayList<SimCoLabels> comps;
    ArrayList<Wire> wires;
    ArrayList<JLabel> textBoxes;

    JLabel textBoxToPlace;

    ImageIcon memoryBoxPic, switchOpenPic, switchClosedPic, wirePic, computationUnitPic;

    public WorkspacePanel(WorkSpace ws) {
        this.ws = ws;
        memoryBoxPic = new ImageIcon("resources/box.png");
        switchOpenPic = new ImageIcon("resources/switchoff.png");
        switchClosedPic = new ImageIcon( "resources/switchon.png");
        wirePic = new ImageIcon("resources/wire.png");
        computationUnitPic = new ImageIcon("resources/calc.png");
        comps = new ArrayList<>();
        wires = new ArrayList<>();
        textBoxes = new ArrayList<>();
        addMouseListener(new MListener());
        addMouseListener(new PanelElementListener());
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(Color.WHITE);

        for (SimCoLabels lb : comps) {
            lb.setBounds(lb.getX(), lb.getY(), 100, 80);
            add(lb);
        }

        for (Wire wire : wires) {
//            System.out.println((int) wire.getStartingPoint().getX() + "bolu" + (int) wire.getStartingPoint().getY() + "" + (int) wire.getStoppingPoint().getX() + "" + (int) wire.getStoppingPoint().getY());
            if ( wire != null && wire.getStoppingPoint() != null && wire.getStartingPoint() != null )
            {
                g.drawLine((int) wire.getStartingPoint().getX(), (int) wire.getStartingPoint().getY(), (int) wire.getStoppingPoint().getX(), (int) wire.getStoppingPoint().getY());
            }
        }

        for (JLabel textBox : textBoxes) {
            textBox.setBounds(textBox.getX(), textBox.getY(), 100, 100);
            add(textBox);
        }
    }

    public void setTextBoxToPlace(JLabel textBoxToPlace) {
        this.textBoxToPlace = textBoxToPlace;
    }

    public JLabel getTextBoxToPlace() {
        return textBoxToPlace;
    }

    private class MListener extends MouseAdapter {
        public void mouseReleased(MouseEvent e) {
            CircuitElement element = ws.getElementToPlace();
            if (element != null) {
                element.setxPos(e.getX() - 25);
                element.setyPos(e.getY() - 25);
                SimCoLabels label = new SimCoLabels(element);
                comps.add(label);
                ws.setElementToPlace(null);
                repaint();
            }
        }

        public void mousePressed( MouseEvent e)
        {
            int x = e.getX();
            int y = e.getY();
            MemoryBlock memoryBlock;
            ComputationUnit computationUnit;
            Switch sswitch;
            String response;
            boolean state;

            if( e.getButton() == MouseEvent.BUTTON3)
            {
                for ( SimCoLabels label : comps )
                {
                    if ( label.contains(x, y) && label.getCircuitElement() instanceof MemoryBlock )
                    {
                        response = (String)JOptionPane.showInputDialog(null,
                                "Enter a value for the memory box",
                                "Memory Block",
                                JOptionPane.PLAIN_MESSAGE,
                                null,
                                null,
                                "");
                        memoryBlock = (MemoryBlock) label.getCircuitElement();
                        memoryBlock.setMemoryValue( response);
                    }
                    else if ( label.contains(x, y) && label.getCircuitElement() instanceof ComputationUnit )
                    {
                        response = (String)JOptionPane.showInputDialog(null,
                                "Select the operation for the computation unit",
                                "Computation Unit",
                                JOptionPane.PLAIN_MESSAGE,
                                null,
                                new String[]{ "Addition", "Subtraction", "Multiplication", "Division"},
                                "");
                        computationUnit = (ComputationUnit) label.getCircuitElement();
                        computationUnit.setOperationType( response);
                    }
                    else if ( label.contains(x, y) && label.getCircuitElement() instanceof Switch )
                    {
                        response = (String)JOptionPane.showInputDialog(null,
                                "Select the operation for the computation unit",
                                "Computation Unit",
                                JOptionPane.PLAIN_MESSAGE,
                                null,
                                new String[]{ "Off", "On"},
                                "");
                        sswitch = (Switch) label.getCircuitElement();
                        if ( response.equals( "Off"))
                        {
                            sswitch.setState( false);
                            label.setIcon( switchOpenPic);
                        }
                        else
                        {
                            sswitch.setState( true);
                            label.setIcon( switchClosedPic);
                        }
                    }

                }
            }
        }
    }

    private class MTextBoxListener extends MouseAdapter {
        public void mouseReleased(MouseEvent e) {
            JLabel label = getTextBoxToPlace();
            if (label != null) {
                TextBoxLabel textBox = new TextBoxLabel();
                textBox.setX(e.getX());
                textBox.setY(e.getY());
                textBoxes.add(textBox);
                setTextBoxToPlace(null);
                repaint();
            }
        }
    }

    private class PanelElementListener extends MouseAdapter {
        CircuitElement startElement;
        CircuitElement stopElement;
        Boolean success;
        Point start;
        Point stop1;
        Point stop2;
        Wire wireTemp;

        @Override
        public void mousePressed(MouseEvent e) {
            int x = e.getX();
            int y = e.getY();

            for (SimCoLabels lb : comps) {
                CircuitElement reference2 = lb.getCircuitElement();
                if (reference2 instanceof MemoryBlock || reference2 instanceof Wire || reference2 instanceof Switch || reference2 instanceof NotGate) {
                    if (lb.contains(x, y) && lb.getX() < x && x < lb.getX() + 15 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        stopElement = lb.getCircuitElement();
                        stop1 = new Point(x, y);
                        System.out.println("mousepressmemoryblockinput");
                        System.out.println("x" + x + " y" + y);
                        success = false;
                    } else if (lb.contains(x, y) && lb.getX() + 85 < x && x < lb.getX() + 100 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        startElement = lb.getCircuitElement();
                        start = new Point(x, y);
                        System.out.println("mousepressedmemoryblockoutput");
                        System.out.println("x" + x + " y" + y);
                        success = false;
                    }
                }
                else
                {
                    if (lb.contains(x, y) && lb.getX() < x && x < lb.getX() + 15 && lb.getY() + 16 < y && y < lb.getY() + 32) {
                        stopElement = lb.getCircuitElement();
                        stop1 = new Point(x, y);
                        System.out.println("mousepressedotherinput1");
                        System.out.println("x" + x + " y" + y);
                        success = false;
                    } else if (lb.contains(x, y) && lb.getX() < x && x < lb.getX() + 15 && lb.getY() + 48 < y && y < lb.getY() + 64) {
                        stopElement = lb.getCircuitElement();
                        stop2 = new Point(x, y);
                        System.out.println("mousepressedotherinput2");
                        System.out.println("x" + x + " y" + y);
                        success = false;
                    } else if (lb.contains(x, y) && lb.getX() + 85 < x && x < lb.getX() + 100 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        startElement = lb.getCircuitElement();
                        start = new Point(x, y);
                        System.out.println("mouse pressed start element");
                        System.out.println("x" + x + " y" + y);
                        success = false;
                    }
                }
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            success = false;
            int x = e.getX();
            int y = e.getY();

            for (SimCoLabels lb : comps) {
                CircuitElement reference2 = lb.getCircuitElement();
                if (reference2 instanceof MemoryBlock || reference2 instanceof Wire || reference2 instanceof Switch || reference2 instanceof NotGate) {
                    if (lb.contains(x, y) && lb.getX() < x && x < lb.getX() + 15 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        stopElement = lb.getCircuitElement();
                        stop1 = new Point(x, y);
                        System.out.println("input");
                        System.out.println("x" + x + " y" + y);
                    } else if (lb.contains(x, y) && lb.getX() + 85 < x && x < lb.getX() + 100 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        startElement = lb.getCircuitElement();
                        start = new Point(x, y);
                        System.out.println("output");
                        System.out.println("x" + x + " y" + y);
                    }

                    //DRAW FOR 1 INPUT ELEMENTS

                    if ( startElement != null && stopElement != null && !success && ( stopElement instanceof MemoryBlock || stopElement instanceof  Wire || stopElement instanceof Switch || stopElement instanceof  NotGate )) {
                        wireTemp = new Wire(startElement, stopElement, "r", start, stop1);
                        wireTemp.setPrev1( startElement);
                        wireTemp.setNext( stopElement);
                        startElement.setNext( wireTemp);
                        stopElement.setPrev1( wireTemp);
                        wires.add(wireTemp);
                        ws.add(wireTemp);
                        System.out.println("wire draw for 1 element");
                        success = true;
                    }
                    repaint();
                }
                else
                {
                    if (lb.contains(x, y) && lb.getX() < x && x < lb.getX() + 15 && lb.getY() + 16 < y && y < lb.getY() + 32) {
                        stopElement = lb.getCircuitElement();
                        stop1 = new Point(x, y);
                        System.out.println("input1input1input1");
                        System.out.println("x" + x + " y" + y);
                    }
                    else if ((lb.contains(x, y)) && (lb.getX() < x) && (x < lb.getX() + 15) && (lb.getY() + 48 < y) && (y < lb.getY() + 64)) {
                        stopElement = lb.getCircuitElement();
                        stop2 = new Point(x, y);
                        System.out.println("input2input2input2");
                        System.out.println("x" + x + " y" + y);
                        System.out.println( "stop2: " + stop2);
                    }
                    else if (lb.contains(x, y) && lb.getX() + 85 < x && x < lb.getX() + 100 && lb.getY() + 32 < y && y < lb.getY() + 48) {
                        startElement = lb.getCircuitElement();
                        start = new Point(x, y);
                        lb.setOutputOccupied( true);
                        System.out.println("outputcalc");
                        System.out.println("x" + x + " y" + y);
                    }

                    if (startElement != null && stopElement != null && start != null && stop1 != null && !lb.input1Occupied && !success) {
                        wireTemp = new Wire(startElement, stopElement, "r", start, stop1);
                        startElement.setNext( wireTemp);
                        wireTemp.setPrev1( startElement);
                        wireTemp.setNext( stopElement);
                        stopElement.setPrev1( wireTemp);
                        lb.setInput1Occupied( true);
                        wires.add(wireTemp);
                        ws.add(wireTemp);
                        System.out.println("A");
                        System.out.println("stop1draw");
                        System.out.println( "start: " + start);
                        System.out.println( "stop1: " + stop1);
                        success = true;
                    }
                    else if (startElement != null && stopElement != null && start != null && stop2 != null && !lb.input2Occupied && !success) {
                        wireTemp = new Wire(startElement, stopElement, "r", start, stop2);
                        lb.setInput2Occupied( true);
                        startElement.setNext( wireTemp);
                        wireTemp.setPrev1( startElement);
                        wireTemp.setNext( stopElement);
                        stopElement.setPrev2( wireTemp);
                        wires.add(wireTemp);
                        ws.add(wireTemp);
                        System.out.println("A");
                        System.out.println("stop2draw");
                        System.out.println( "start: " + start);
                        System.out.println( "stop2: " + stop2);
                        success = true;
                    }
                    repaint();
                }
            }
            /*if (startElement != null && stopElement != null) {
                wireTemp = new Wire(startElement, stopElement, "r", start, stop1);
                wires.add(wireTemp);
                ws.add(wireTemp);
                System.out.println("A");
                repaint();
                System.out.println("not null elements");
            }*/
            /*start = new Point( 0, 0);
            stop1  = new Point( 0, 0);
            stop2 = new Point( 0, 0);*/
            start = null;
            stop1  = null;
            stop2 = null;

            startElement = null;
            stopElement = null;
        }
    }


    private class SimCoLabels extends JLabel {
        CircuitElement e;
        boolean input1Occupied;
        boolean input2Occupied;
        boolean outputOccupied;


        public SimCoLabels(CircuitElement e) {
            super();
            this.e = e;
            setBounds(e.getxPos(), e.getyPos(), 100, 100);
            ws.add(e);
            if (e instanceof MemoryBlock) {
                setIcon(memoryBoxPic);
            } else if (e instanceof Switch) {
                setIcon(switchOpenPic);
            } else if (e instanceof ComputationUnit) {
                setIcon(computationUnitPic);
            }

            input1Occupied = false;
            input2Occupied = false;
            outputOccupied = false;


        }

        public int getX() {
            return e.getxPos();
        }


        public int getY() {
            return e.getyPos();
        }

        public void setX(int xPos) {
            e.setxPos(xPos);
        }

        public void setY(int yPos) {
            e.setxPos(yPos);
        }

        public CircuitElement getCircuitElement() {
            return e;
        }

        public boolean contains(int x, int y) {
            if (getX() < x && x < getX() + 100 && getY() < y && y < getY() + 100) {
                return true;
            }
            return false;
        }

        public void setInput1Occupied( Boolean occupied)
        {
            input1Occupied = occupied;
        }

        public void setInput2Occupied( Boolean occupied)
        {
            input2Occupied = occupied;
        }

        public void setOutputOccupied( Boolean occupied)
        {
            outputOccupied = occupied;
        }
    }

    private class TextBoxLabel extends JLabel {
        int x, y;

        public TextBoxLabel() {
            setBackground(Color.YELLOW);
        }

        public void setX(int x) {
            this.x = x;
        }

        public void setY(int y) {
            this.y = y;
        }
    }

}
