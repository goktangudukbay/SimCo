import Circuit.WorkSpace;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import javax.swing.*;

public class MainWorkspace extends JFrame
{
    WorkSpace ws;
    File file;
    TopMenuBar menuBar;

    public MainWorkspace( WorkSpace ws, File file)
    {
        this.ws = ws;
        this.file = file;
        if ( file != null )
        {
            try {
                FileInputStream fileIn = new FileInputStream( file.getPath());
                ObjectInputStream in = new ObjectInputStream(fileIn);
                ws = ( WorkSpace) in.readObject();
                in.close();
                fileIn.close();
            } catch (IOException i) {
                i.printStackTrace();
                return;
            } catch (ClassNotFoundException c) {
                System.out.println("Workspace class not found");
                c.printStackTrace();
                return;
            }
        }

        JPanel mainPanel = new JPanel();
        add( mainPanel);
        mainPanel.setLayout(new BorderLayout());

        menuBar = new TopMenuBar( file, ws, this);

        mainPanel.add( menuBar, BorderLayout.NORTH);
        mainPanel.add( new WorkspacePanel( ws), BorderLayout.CENTER);
        mainPanel.add(new ComponentPanel( ws), BorderLayout.SOUTH);

        JButton b = new JButton( "run");
        b.addActionListener( new BL());
        mainPanel.add( b, BorderLayout.EAST);
        setSize( new Dimension( 1000, 800));
        //setSize( Toolkit.getDefaultToolkit().getScreenSize());
        //setLocationRelativeTo(null);
        //setExtendedState( JFrame.MAXIMIZED_BOTH);
        addWindowListener(new WindowAdapter() {
            int response;

            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                response = menuBar.saveAsk();
                if ( response == 1 || response == 0 || response == -2 )
                {
                    dispose();
                }
            }
        });
        setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
        setVisible( true);



    }

    private class BL implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println( ws.getLastElement().run());
        }
    }


}