import Circuit.WorkSpace;
import CircuitElement.*;
import Gates.*;
import java.io.*;

public class TestClass
{
    public static void main( String[] args)
    {
        WorkSpace ws = new WorkSpace();
        MemoryBlock m1 = new MemoryBlock( null, null , "r", "6", 5, 5);
        Wire w1 = new Wire( m1, null, "r", null,null);
        m1.setNext( w1);
        MemoryBlock m2 = new MemoryBlock( w1, null, "r", null, 7, 5);
        w1.setNext( m2);
        ws.add( m1);
        ws.add( m2);
        ws.add( w1);
        
        MemoryBlock m3 = new MemoryBlock( null, null , "r", "4", 5, 7);
        Wire w2 = new Wire( m3, null, "r", null,null);
        m3.setNext( w2);
        MemoryBlock m4 = new MemoryBlock( w2, null, "r", null, 7, 7);
        w2.setNext( m4);
        ws.add( m3);
        ws.add( m4);
        ws.add( w2);
        
        Wire w3 = new Wire( m2, null, "se", null, null);
        Wire w4 = new Wire( m4, null, "ne", null, null);
        
/*        Switch w3 = new Switch( m2, null, "se", 8, 5);
        Switch w4 = new Switch( m4, null, "ne", 8, 7);*/
        
/*        w3.setState( true);
        w4.setState( true);*/
        
        //AndGate andGate = new AndGate( w3, w4, null, "r", 9, 6);
        ComputationUnit cu = new ComputationUnit( w3, w4, null, "r", 9, 6);
        
        Wire w5 = new Wire( cu, null, "r", null, null);
        //andGate.setNext( w5);
        cu.setNext( w5);
        
        MemoryBlock m5 = new MemoryBlock( w5, null, "r", null, 11, 6);
        w5.setNext( m5);
        
        cu.setOperationType( "mult");
        
        
        m2.setNext( w3);
        m4.setNext( w4);
        
        ws.add( cu);
        //ws.add( andGate);
        ws.add( w5);
        ws.add( m5);
        
        ws.run();

        try {
            FileOutputStream fileOut = new FileOutputStream("workspace.simco");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject( ws);
            out.close();
            fileOut.close();
            System.out.println( "Workspace is saved in workspace.simco");
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
}
