      /**
       * Auto Generated Java Class.
       */
      import Circuit.WorkSpace;
      import CircuitElement.*;

      import javax.swing.*;
      import java.awt.event.ActionEvent;
      import java.awt.event.ActionListener;

      public class ComponentPanel extends JPanel {
         //properties
         JButton memoryButton, sswitch, w, computationUnit;
         ButtonGroup buttonGroup;
         WorkSpace ws;
         BListener bListener;

         public ComponentPanel( WorkSpace ws) {
            this.ws = ws;
            bListener = new BListener();
            buttonGroup = new ButtonGroup();
            memoryButton = new ComponentButton( "Memory Block", "resources/memoryBox.png");
            sswitch = new ComponentButton( "Switch","resources/switch2.png");
            computationUnit = new ComponentButton( "Computation Unit","resources/calc1.png");
            buttonGroup.add(memoryButton);
            buttonGroup.add(sswitch);
            buttonGroup.add(computationUnit);
            add(memoryButton);
            add(sswitch);
            add(computationUnit);

         }

         private class ComponentButton extends JButton
         {

            public ComponentButton( String text, String imagePath)
            {
               super( text, new ImageIcon( imagePath));
               setVerticalTextPosition( SwingConstants.BOTTOM);
               setHorizontalTextPosition( SwingConstants.CENTER);
               addActionListener( bListener);
            }
         }

         private class BListener implements ActionListener{
            public void actionPerformed( ActionEvent e){
               if ( e.getSource() == memoryButton){
                  ws.setElementToPlace( new MemoryBlock(  null, null, "", null, 0, 0));
               }
               else if ( e.getSource() == computationUnit){
                  ComputationUnit cu = new ComputationUnit(  null, null, null, "", 0, 0);
                  cu.setOperationType( "Multiplication");
                  ws.setElementToPlace( cu);
               }
               else if ( e.getSource() == sswitch){
                  ws.setElementToPlace( new Switch(  null, null, "", 0, 0));
               }
            }

         }

      }
