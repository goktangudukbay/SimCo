package Animate;

public class Paper
{
    int x;
}
