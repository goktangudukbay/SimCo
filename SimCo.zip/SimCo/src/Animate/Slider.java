package Animate;

import Circuit.Circuit;
import CircuitElement.CircuitElement;

public class Slider
{
    CircPos[] circPos;
    int index;

    public Slider()
    {
        circPos = new CircPos[20];
        index = 0;
    }

    public void addCircPos( int yPos, CircuitElement ce){
        circPos[index] = new CircPos( yPos, ce);
        index++;
    }

    public CircPos getCircPos( int i){
        return circPos[i];
    }

    private class CircPos
    {
        int yPos;
        CircuitElement element;

        public CircPos(int yPos, CircuitElement element)
        {
            this.yPos = yPos;
            this.element = element;
        }

        public int getyPos()
        {
            return yPos;
        }

        public CircuitElement getElement()
        {
            return element;
        }
    }
}
