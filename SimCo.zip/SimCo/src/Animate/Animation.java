package Animate;

public class Animation
{
    Slider slider;

    public Animation( Slider slider)
    {
        this.slider= slider;
    }

    public void run()
    {

    }

    public void pause()
    {

    }

    public void stop()
    {

    }
}
