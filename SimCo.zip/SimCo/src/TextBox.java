import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TextBox extends JButton{

    //properties
//   String info;
    boolean isSelected;
    int x, y;
    TextBoxListener listener;
    WorkspacePanel wsp;

    //constructors
    public TextBox( WorkspacePanel wsp) {
        super( );
        this.wsp = wsp;
        listener = new TextBoxListener();
        addActionListener( listener);
    }

    private class TextBoxListener implements ActionListener{
        public void actionPerformed( ActionEvent e){
            wsp.setTextBoxToPlace( new JLabel());
        }
    }


}

   