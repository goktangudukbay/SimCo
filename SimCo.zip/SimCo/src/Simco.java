public class Simco
{
   public static void main( String[] args)
   {
      new WelcomeFrame();
   }
}