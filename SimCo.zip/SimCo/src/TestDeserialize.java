import Circuit.WorkSpace;
import java.io.*;

public class TestDeserialize
{
   public static void main( String[] args)
   {
      WorkSpace ws;

      try {
         FileInputStream fileIn = new FileInputStream("Workspace.simco");
         ObjectInputStream in = new ObjectInputStream(fileIn);
         ws = ( WorkSpace) in.readObject();
         in.close();
         fileIn.close();
      } catch (IOException i) {
         i.printStackTrace();
         return;
      } catch (ClassNotFoundException c) {
         System.out.println("Workspace class not found");
         c.printStackTrace();
         return;
      }

      ws.run();
   }
}
