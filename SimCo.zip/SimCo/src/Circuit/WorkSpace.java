package Circuit;

import CircuitElement.CircuitElement;

import java.io.Serializable;

/**
 * Auto Generated Java Class.
 */
public class WorkSpace extends Circuit implements Serializable {

   CircuitElement elementToPlace;

   public WorkSpace() {}
   /* ADD YOUR CODE HERE */
   
   
   public void add( CircuitElement circuitElement)
   {
      components.add( circuitElement);
   }

   public void remove( CircuitElement circuitElement)
   {
      components.remove( circuitElement);
   }

   public CircuitElement getLastElement()
   {
      for ( CircuitElement element : components)
      {
         if ( element.getNext() == null )
         {
            return element;
         }
      }
      return null;
   }

   public CircuitElement getLastPlacedElement()
   {
      return components.get( components.size() - 1);
   }

   public void setElementToPlace( CircuitElement elementToPlace)
   {
      System.out.println( "setelementtoplace");
      this.elementToPlace = elementToPlace;
   }

   public CircuitElement getElementToPlace()
   {
      return elementToPlace;
   }

   public void run()
   {
      CircuitElement lastElement = getLastElement();
      if ( lastElement != null )
      {
         lastElement.run();
         System.out.println( lastElement.getTempValue());
      }
   }

   public boolean isEmpty()
   {
      if ( components.size() == 0 )
      {
         return true;
      }
      return false;
   }
}
