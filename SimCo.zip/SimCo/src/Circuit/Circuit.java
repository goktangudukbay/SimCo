package Circuit;

import CircuitElement.CircuitElement;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Auto Generated Java Class.
 */
public abstract class Circuit implements Serializable
{
   //properties
   //CircuitElement[][] components;
   ArrayList< CircuitElement> components;

   //constants
   //final int arrayLength = 20;
   
   //constructors
   /*//public Circuit()
   {
      components = new CircuitElement[arrayLength][arrayLength];
   }*/

   public Circuit()
   {
      components = new ArrayList<>();
   }

   /*public Circuit( int x, int y)
   {
      components = new CircuitElement[x][y];
   }*/


}
