package Circuit;

/**
 * Auto Generated Java Class.
 */
public class UserDefined extends Circuit {
   
   public UserDefined() { 
      /* YOUR CONSTRUCTOR CODE HERE*/
   }
   /* ADD YOUR CODE HERE */
   
}
