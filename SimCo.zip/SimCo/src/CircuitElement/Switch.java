package CircuitElement;

/**
 * Auto Generated Java Class.
 */
public class Switch extends CircuitElement {
   //properties
   boolean state;
   //constants
   
   //constructors
   public Switch( CircuitElement prev1, CircuitElement next, String direction, int xPos, int yPos) {
      super( prev1, next, direction, xPos, yPos);
      state = false;
   }

   
   //methods
   
   public void setState( boolean state){
      this.state = state;
   }
   
   public boolean getState(){
      return state;
   }

   public String run()
   {
      if ( !getState() || prev1 == null )
      {
         tempValue = "0";
         prev1.run();
         return tempValue;
      }
      else
      {
         tempValue = prev1.run();
         return tempValue;
      }
   }
   
}
