package CircuitElement;

import Circuit.Circuit;

import java.awt.*;
import java.io.Serializable;

/**
 * Auto Generated Java Class.
 */
public abstract class CircuitElement implements Serializable
{
   
   //properties
   int xPos, yPos;
   CircuitElement prev1, prev2, next;
   String direction, tempValue;
   Point start, stop;
   //constants
   
   //constructors
   public CircuitElement( CircuitElement prev1, CircuitElement next, String direction, int xPos, int yPos)
   {
      this.prev1 = prev1;
      this.next = next;
      this.direction = direction;
      this.xPos = xPos;
      this.yPos = yPos;
   }

   public CircuitElement( CircuitElement prev1, CircuitElement prev2, CircuitElement next, String direction, int xPos, int yPos)
   {
      this.prev1 = prev1;
      this.prev2 = prev2;
      this.next = next;
      this.direction = direction;
      this.xPos = xPos;
      this.yPos = yPos;
   }

   public CircuitElement(CircuitElement prev1, CircuitElement next, String direction, Point start, Point stop)
   {
      this.prev1 = prev1;
      this.next = next;
      this.direction = direction;
      this.start = start;
      this.stop = stop;
   }


   public void setDirection(String direction) {
      this.direction = direction;
   }

   public String getDirection()
   {
      return direction;
   }

   public void setPrev1(CircuitElement prev1)
   {
      this.prev1 = prev1;
   }

   public void setPrev2(CircuitElement prev2)
   {
      this.prev2 = prev2;
   }

   public void setNext(CircuitElement next)
   {
      this.next = next;
   }

   public CircuitElement getPrev1()
   {
      return prev1;
   }

   public CircuitElement getPrev2()
   {
      return prev2;
   }

   public CircuitElement getNext()
   {
      return next;
   }

   public void setTempValue( String tempValue)
   {
      this.tempValue = tempValue;
   }

   public String getTempValue()
   {
      return tempValue;
   }

   public int getxPos()
   {
      return xPos;
   }

   public int getyPos()
   {
      return yPos;
   }

   public void setxPos( int xPos)
   {
      this.xPos = xPos;
   }

   public void setyPos( int yPos)
   {
      this.yPos = yPos;
   }

   public abstract String run();

   public Point getStart() {
      return start;
   }
   public Point getStop() {
      return stop;
   }
}
