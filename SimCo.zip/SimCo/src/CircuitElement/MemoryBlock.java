package CircuitElement;

public class MemoryBlock extends CircuitElement {
   //properties
   String memoryValue;
   //constants
   
   //constructors
   public MemoryBlock( CircuitElement prev1, CircuitElement next, String direction, String memoryValue, int xPos, int yPos) {
      super( prev1, next, direction, xPos, yPos);
      this.memoryValue = memoryValue;
   }
   
   public void setMemoryValue( String memoryValue)
   {
      this.memoryValue = memoryValue;
   }
   
   public String getMemoryValue()
   {
      return memoryValue;
   }

   public String run()
   {
      if ( memoryValue == null )
      {
         memoryValue = prev1.run();
      }

      tempValue = memoryValue;
      return memoryValue;

   }
}
