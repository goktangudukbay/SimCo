package CircuitElement;

/**
 * Auto Generated Java Class.
 */
public class ComputationUnit extends CircuitElement {
   //properties
   String operand1;
   String operand2;
   String result;
   String operationType;

   //constructors
   public ComputationUnit( CircuitElement prev1, CircuitElement prev2, CircuitElement next, String direction, int xPos, int yPos)
   {
      super( prev1, prev2, next, direction, xPos, yPos);
   }

   public void setOperand1( String operand1){
      this.operand1 = operand1;
   }

   public void setOperand2( String operand2){
      this.operand2 = operand2;
   }

   public String getOperand11(){
      return operand1;
   }
   
   public String getOperand22(){
      return operand2;
   }

   public void setOperationType( String operationType)
   {
      this.operationType = operationType;
   }

   public String getResult()
   {
      if ( operationType == null )
      {
         //set result by prompting the user
      }
      else if ( operationType.equals( "Addition") )
      {
         result = Integer.toString(Integer.parseInt( operand1) + Integer.parseInt( operand2));
      }
      else if ( operationType.equals( "Subtraction") )
      {
         result = Integer.toString(Integer.parseInt( operand1) - Integer.parseInt( operand2));
      }
      else if ( operationType.equals( "Multiplication") )
      {
         result = Integer.toString(Integer.parseInt( operand1) * Integer.parseInt( operand2));
      }
      else if ( operationType.equals( "Division") )
      {
         //Will give integer divison result.
         result = Integer.toString(Integer.parseInt( operand1) / Integer.parseInt( operand2));
      }

      return result;
   }

   public String operation( String result){
      this.result = result;   
      return result;
   }
   
   public void setResult( String result) {
      this.result = result;
   }

   public String run()
   {
      if ( prev1 == null)
      {
         //Get input from the user
      }
      else
      {
         operand1 = prev1.run();
      }

      if ( prev2 == null)
      {
         //Get input from the user
      }
      else
      {
         operand2 = prev2.run();
      }

      tempValue = getResult();
      return tempValue;
   }
   
   
}
