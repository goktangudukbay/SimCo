package CircuitElement;

import java.awt.*;

/**
 * Auto Generated Java Class.
 */
public class Wire extends CircuitElement {
   //properties
   
   //constants
   
   //constructors
   public Wire(CircuitElement prev1, CircuitElement next, String direction, Point start, Point stop) {
      super( prev1, next, direction, start, stop);
   }

   public String run()
   {
      //wire must have a previous element
      if ( prev1 == null)
      {
         tempValue = "0";
         return tempValue;
      }
      else
      {
         tempValue = prev1.run();
         return tempValue;
      }
   }

   public Point getStartingPoint()
   {
      return start;
   }

   public Point getStoppingPoint()
   {
      return stop;
   }

}
