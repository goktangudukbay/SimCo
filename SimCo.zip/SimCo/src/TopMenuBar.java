import Circuit.WorkSpace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URI;
import java.io.File;
import java.net.URISyntaxException;


public class TopMenuBar extends JMenuBar
{
    JMenu fileMenu, editMenu, viewMenu, helpMenu;
    JMenuItem fileNew, fileOpen, fileSave, fileSaveAs, fileExport, fileQuit;
    JMenuItem editCopy, editCut, editPaste, editClear;
    JCheckBox viewFunctions, viewComponents, viewSwitches, viewGridLines;
    JMenuItem helpTutorial, helpInstructions;
    File file;
    WorkSpace ws;
    JFileChooser fileChooser;
    JFrame frame;

    public TopMenuBar( File file, WorkSpace ws, JFrame frame)
    {
        this.file = file;
        this.ws = ws;
        this.frame = frame;
        fileChooser = new JFileChooser();

        Font font = new Font("Arial", Font.PLAIN, 20);
        setBackground( new Color( 203, 237, 255));

        FileMenuAL fileMenuAL = new FileMenuAL();
        fileMenu = new JMenu( "File");
        fileMenu.setFont(font);
        fileNew = new MenuItemWithAL( "New", fileMenuAL);
        fileMenu.add( fileNew);
        fileOpen = new MenuItemWithAL( "Open", fileMenuAL);
        fileMenu.add( fileOpen);
        fileSave = new MenuItemWithAL( "Save", fileMenuAL);
        fileMenu.add( fileSave);
        fileSaveAs = new MenuItemWithAL( "Save As", fileMenuAL);
        fileMenu.add( fileSaveAs);
        fileExport = new MenuItemWithAL( "Export", fileMenuAL);
        fileMenu.add( fileExport);
        fileQuit = new MenuItemWithAL( "Quit", fileMenuAL);
        fileMenu.add( fileQuit);
        add( fileMenu);


        EditMenuAL editMenuAL = new EditMenuAL();
        editMenu = new JMenu( "Edit");
        editMenu.setFont(font);
        editCopy = new MenuItemWithAL( "Cut", editMenuAL);
        editMenu.add( editCopy);
        editCut = new MenuItemWithAL( "Copy", editMenuAL);
        editMenu.add( editCut);
        editPaste = new MenuItemWithAL( "Paste", editMenuAL);
        editMenu.add( editPaste);
        editClear = new MenuItemWithAL( "Clear", editMenuAL);
        editMenu.add( editClear);
        add( editMenu);

        ViewMenuIL viewMenuAL = new ViewMenuIL();
        viewMenu = new JMenu( "View");
        viewMenu.setFont( font);
        viewFunctions = new CheckboxWithAL( "Functions", viewMenuAL);
        viewMenu.add( viewFunctions);
        viewComponents = new CheckboxWithAL( "Components", viewMenuAL);
        viewMenu.add( viewComponents);
        viewSwitches = new CheckboxWithAL( "Switches", viewMenuAL);
        viewMenu.add( viewSwitches);
        viewGridLines = new CheckboxWithAL( "Grid Lines", viewMenuAL);
        viewMenu.add( viewGridLines);
        add( viewMenu);

        HelpMenuAL helpMenuAL = new HelpMenuAL();
        helpMenu = new JMenu( "Help");
        helpMenu.setFont( font);
        helpTutorial= new MenuItemWithAL( "Tutorial", helpMenuAL);
        helpMenu.add( helpTutorial);
        helpInstructions = new MenuItemWithAL( "Instructions", helpMenuAL);
        helpMenu.add( helpInstructions);
        add( helpMenu);
    }

    public void saveFile( String path)
    {
        try {
            FileOutputStream fileOut = new FileOutputStream( path);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject( ws);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public int saveAsk()
    {
        String message;
        int response;

        if ( !ws.isEmpty() )
        {
            //untitled workspace
            if ( file == null )
            {
                message = "Do you want to save changes to Untitled?";
            }
            //saved on a file workspace
            else
            {
                message = "Do you want to save changes to " + "\"" + file.getPath() + "\"?";
            }
            response = JOptionPane.showOptionDialog( null, message, "SimCo", JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE, null, new String[]{ "Save", "Don't Save", "Cancel"}, null);

            //if user chooses to save
            if ( response == JOptionPane.YES_OPTION )
            {
                //untitled workspace
                if ( file == null )
                {
                    response = fileChooser.showSaveDialog( frame);

                    //if pressed on the save button with a filename
                    if ( response == JFileChooser.APPROVE_OPTION )
                    {
                        file = fileChooser.getSelectedFile();
                        saveFile( file.getPath());
                        return 1;
                        /*frame.dispose();
                        new MainWorkspace( new WorkSpace(), null);*/
                    }
                }
                //save the changes to the current file
                else
                {
                    saveFile( file.getPath());
                    return 1;
                }
            }
            //if the user chooses not to save
            else if ( response == JOptionPane.NO_OPTION )
            {
                return 0;
                //frame.dispose();
                //new MainWorkspace( new WorkSpace(), null);

            }
            else if ( response == JOptionPane.CANCEL_OPTION)
            {
                return -1;
            }
            //nothing happens if they cancel
        }
        //return -2 if the workspace is empty
        return -2;
    }

    private class FileMenuAL implements ActionListener
    {
        @Override
        public void actionPerformed( ActionEvent e)
        {
            String message;
            MainWorkspace mws;
            int response, option;

            //NEW
            if ( e.getSource() == fileNew )
            {
                response = saveAsk();
                if ( response == 1 || response == 0 )
                {
                    frame.dispose();
                    mws = new MainWorkspace( new WorkSpace(), null);
                    mws.setLocationRelativeTo( null);
                }
            }
            //OPEN
            else if ( e.getSource() == fileOpen )
            {
                //if there is a file ask if the user wants to save
                //can use fileQuit code here
                //file open box
                //new mainworkspace with the loaded file
                response = saveAsk();
                if ( response == 1 || response == 0 || response == -2 )
                {
                    option = fileChooser.showOpenDialog( frame);

                    if ( option == JFileChooser.APPROVE_OPTION )
                    {
                        file = fileChooser.getSelectedFile();
                        frame.dispose();
                        mws = new MainWorkspace( new WorkSpace(), file);
                        mws.setLocationRelativeTo( null);
                    }
                }


            }
            else if ( e.getSource() == fileSave )
            {
                //If there is not a file yet show the save box
                //Serialize the workspace to the path gotten from the save box
                //If there is a current file just serialize again on it
                if ( file == null )
                {
                    response = fileChooser.showSaveDialog( frame);

                    //if pressed on the save button with a filename
                    if ( response == JFileChooser.APPROVE_OPTION )
                    {
                        file = fileChooser.getSelectedFile();
                        saveFile( file.getPath());
                    }
                }
                //save the changes to the current file
                else
                {
                    saveFile( file.getPath());
                }
            }
            else if ( e.getSource() == fileSaveAs )
            {
                response = fileChooser.showSaveDialog( frame);

                if ( response == JFileChooser.APPROVE_OPTION )
                {
                    file = fileChooser.getSelectedFile();
                    saveFile( file.getPath());
                }

            }
            else if ( e.getSource() == fileExport )
            {
                //gif or jpeg ideally
            }
            else if ( e.getSource() == fileQuit )
            {
                //Do you want to save the changes for unnamed, save dont save, cancel
                //Do you want to save the changes to "path to file" save dont save, cancel
                // Confirmation do you want to exit ?? without saving
                response = saveAsk();
                if ( response == 1 || response == 0 || response == -2 )
                {
                    frame.dispose();
                }
            }
        }
    }

    private class EditMenuAL implements ActionListener
    {
        @Override
        public void actionPerformed( ActionEvent e)
        {
            if ( e.getSource() == editCopy )
            {

            }
            else if ( e.getSource() == editCut )
            {

            }
            else if ( e.getSource() == editPaste )
            {

            }
            else if ( e.getSource() == editClear )
            {

            }
        }
    }

    //Item listener for the view menu
    private class ViewMenuIL implements ItemListener
    {
        @Override
        public void itemStateChanged(ItemEvent e)
        {
            //toggle the visibility of the component, resize it to 0 or remove
            //it from the panel while still holding the reference to it
            if ( e.getSource() == viewFunctions )
            {
                if ( e.getStateChange() == ItemEvent.SELECTED )
                {

                }
                else
                {

                }
            }
            else if ( e.getSource() == viewComponents )
            {
                if ( e.getStateChange() == ItemEvent.SELECTED )
                {

                }
                else
                {

                }
            }
            else if ( e.getSource() == viewSwitches )
            {
                if ( e.getStateChange() == ItemEvent.SELECTED )
                {

                }
                else
                {

                }
            }
            else if ( e.getSource() == viewGridLines )
            {
                if ( e.getStateChange() == ItemEvent.SELECTED )
                {

                }
                else
                {

                }
            }
        }
    }

    private class HelpMenuAL implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if ( e.getSource() == helpTutorial ) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.google.com"));
                }
                catch ( URISyntaxException u)
                {
                    return;
                }
                catch ( IOException i)
                {
                    return;
                }
            }
            else if ( e.getSource() == helpInstructions )
            {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.google.com"));
                }
                catch ( URISyntaxException u)
                {
                    return;
                }
                catch ( IOException i)
                {
                    return;
                }
            }
        }
    }

    private class MenuItemWithAL extends JMenuItem
    {
        public MenuItemWithAL(String text, ActionListener al)
        {
            super( text);
            addActionListener( al);
        }
    }

    private class CheckboxWithAL extends JCheckBox
    {
        public CheckboxWithAL( String text, ItemListener il)
        {
            super( text);
            addItemListener( il);
        }
    }

}
